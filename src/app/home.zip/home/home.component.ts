import { Component } from '@angular/core';
import { ApiService } from '../api.service';
import { CommonModule } from '@angular/common';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  categorie = [

    /* Cosmetics */
    {
      name: 'Cosmetic',
      tabs: ['All', 'Lotion', 'Mask', 'Perfume'],
      products: [
        {
          title: 'CIC2 Skin Decode Kit',
          price: '$690.30',
          by: 'CO., LTD Baby Girl',
          badge: 'New',
          badgeType: 'new',
          image: 'https://via.placeholder.com/150'
        },
        {
          title: 'Angel Whitening Treatment Lotion',
          price: '$132.90',
          by: 'CO., LTD Beautiful Face',
          badge: 'Favorite',
          badgeType: 'favorite',
          image: 'https://via.placeholder.com/150'
        },
        {
          title: 'Sunscreen moisturizing intensify',
          price: '$69.04',
          by: 'CO., LTD Baby Girl',
          badge: 'Sold Out',
          badgeType: 'sold',
          image: 'https://via.placeholder.com/150'
        },
        {
          title: 'Anti-allergy serum',
          price: '$132.90',
          by: 'CO., LTD Skincare Cosmetic',
          image: 'https://via.placeholder.com/150'
        }
      ]
    },

    /* Real Estate */
    {
      name: 'Real Estate',
      tabs: ['All', 'House', 'Land', 'House for rent'],
      products: [
        {
          title: 'Apartment for rent in GLEA CENTRAL',
          price: '$2500 /Month',
          by: 'Flower Real Estate',
          badge: 'New',
          badgeType: 'new',
          image: 'https://via.placeholder.com/300x200'
        },
        {
          title: 'For Rent DALA GOLDEN RIVER',
          price: 'Price Agreement',
          by: 'Vanguard',
          badge: 'Watch a lot',
          badgeType: 'watch',
          image: 'https://via.placeholder.com/300x200'
        },
        {
          title: 'Apartment for rent in DIAMOND',
          price: '$4505 /Month',
          by: 'Flower Real Estate',
          badge: 'Deal',
          badgeType: 'deal',
          image: 'https://via.placeholder.com/300x200'
        },
        {
          title: 'Apartment in District 10',
          price: '$517.79 /Month',
          by: '247 Real Estate',
          badge: 'Ordered',
          badgeType: 'sold',
          image: 'https://via.placeholder.com/300x200'
        }
      ]
    },

    /* Luxury Food */
    {
      name: 'Luxury Food',
      tabs: ['All', 'Drinks', 'Preparation', 'Cereals'],
      products: [
        {
          title: 'Fujiwa alkaline ion drink',
          price: '$32',
          by: 'FUJIWA USA',
          badge: 'New',
          badgeType: 'new',
          image: 'https://via.placeholder.com/150'
        },
        {
          title: 'Fujiwa alkaline drinking water',
          price: '$2300',
          by: 'FUJIWA USA',
          badge: 'New',
          badgeType: 'new',
          image: 'https://via.placeholder.com/150'
        },
        {
          title: 'Pure Kim Non Tapioca Flour',
          price: '$58',
          by: 'Gesun Investment',
          image: 'https://via.placeholder.com/150'
        },
        {
          title: 'Oak Wine',
          price: '$5179',
          by: 'Gesun Investment',
          image: 'https://via.placeholder.com/150'
        }
      ]
    }

  ];
products: any[] = [];
filteredProducts: any[] = [];
categories: string[] = [];

activeCategory: string = 'All';
searchTerm: string = '';

  constructor(private api: ApiService,private cartService: CartService) {}

  ngOnInit(): void {
  this.api.getProducts().subscribe(data => {
    this.products = data;
    this.filteredProducts = data;

    this.categories = ['All', ...new Set(data.map((p: any) => p.category))];
  });
}

filterByCategory(category: string) {
  this.activeCategory = category;
  this.applyFilters();
}

onSearch(event: Event) {
  this.searchTerm = (event.target as HTMLInputElement).value.toLowerCase();
  this.applyFilters();
}

applyFilters() {
  this.filteredProducts = this.products.filter(product => {

    const matchCategory =
      this.activeCategory === 'All' ||
      product.category === this.activeCategory;

    const matchSearch =
      product.title.toLowerCase().includes(this.searchTerm) ||
      product.category.toLowerCase().includes(this.searchTerm);

    return matchCategory && matchSearch;
  });
}
  cartItem(product:any){
    this.cartService.addToCart(product);
  }
}
